let email=document.getElementById("email");
let pwd=document.getElementById("pwd");
function checkvalidation(){
  window.location="main.html";
}

function validate(callback){
    if(email.value == "admin" && pwd.value == "12345")
    {
    callback();
    
    }
   else
   {
      return false;
    }
  
    
    
}
 function validatefunction()
 {
  validate(checkvalidation);
 }


